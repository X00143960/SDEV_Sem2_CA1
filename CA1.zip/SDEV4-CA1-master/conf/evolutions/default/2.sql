# --- Sample dataset
 
# --- !Ups
 
delete from employee;
delete from project;
delete from address;
delete from department;
delete from user;

insert into project (id,name) values (1,'Proj 1');
insert into project (id,name) values (2,'Proj 2');
insert into project (id,name) values (3,'Proj 3');


insert into department (id,name) values (1,'Human Resources');
insert into department (id,name) values (2,'Accountancy');
insert into department (id,name) values (3,'Sales');

insert into address (add_id,town,eir_code) values (1,'Naas','W91W7P6');
insert into address (add_id,town,eir_code) values (2,'Dublin 12','P45W7P6');
insert into address (add_id,town,eir_code) values (3,'Dublin 3','P45O7T6');
insert into address (add_id,town,eir_code) values (4,'Dublin 7','P77R7T9');


 
insert into employee (id,name,startdate,salary,dep_id,aid) values (1,'John Doe','29/APR/2014',4000.00 ,1,1);
insert into employee (id,name,startdate,salary,dep_id,aid) values (2,'Jeny Logan','29/APR/2014',4000.00,1,2);
insert into employee (id,name,startdate,salary,dep_id,aid) values (3,'Patrick Black','29/APR/2014',4000.00,2,3);
insert into employee (id,name,startdate,salary,dep_id,aid) values (4,'Michael Dean','29/APR/2014',4000.00,3,4);


 
insert into project_employee (project_id,employee_id) values (1,1);
insert into project_employee (project_id,employee_id) values (2,2);
insert into project_employee (project_id,employee_id) values (3,3);
insert into project_employee (project_id,employee_id) values (3,2);
insert into project_employee (project_id,employee_id) values (2,4);



insert into user (email,name,password,role) values ( 'admin@products.com', 'George Admin', 'password', 'admin' );





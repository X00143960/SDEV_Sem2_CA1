package models;

import io.ebean.Model;
import play.data.validation.Constraints;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Address extends Model {

    // Properties
    @Id
    private Long addId;

    @Constraints.Required
    public String town;

    @Constraints.Required
    public String eirCode;


    public Address() {
    }

    // Constructor to initialise object
    public Address(String town, String eirCode) {
        this.town = town;
        this.eirCode = eirCode;
    }

    public Long getAddressId() {
        return addId;
    }

    public void setAddressId(Long addressId) {
        this.addId = addressId;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getEirCode() {
        return eirCode;
    }

    public void setZipCode(String zipCode) {
        this.eirCode = zipCode;
    }
}
    
package models;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Employee extends Model {

    // Properties
    @Id
    public Long id;

    @Constraints.Required
    public String name;

    @Constraints.Required
    public String startdate;

    @Constraints.Required
    public double salary;

    @ManyToOne (cascade = CascadeType.ALL)
    private Department dep;

    @OneToOne(cascade = CascadeType.REMOVE)
    @JoinColumn(name = "AID")
    private Address address;

    @ManyToMany(cascade =CascadeType.ALL, mappedBy = "employees")
    public List<Project> projects;
    @Constraints.Required




    public List<Long> pList = new ArrayList<Long>();

    public static final Finder<Long, Employee> find = new Finder<>(Employee.class);


    public static final List<Employee> findAll() {

        return Employee.find.all();
    }
    // Default Constructor
    public Employee() {
    }

    // Constructor to initialise object
    public Employee( String name, String startdate, double salary) {

        this.name = name;
        this.startdate = startdate;
        this.salary = salary;
    }

    // Accessor methods
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public List<Long> getpListSelect() {
        return pList;
    }

    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setpList(List<Long> pList) {
        this.pList = pList;
    }
    public String  getStartdate() {
        return startdate;
    }
    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }



    public void setDep(Department dep) {
        this.dep = dep;
    }
    public Department getDep() {
        return dep;
    }

    public Address getAddress() {
        return address;
    }
    public void setAddress(Address address) {
        this.address = address;
    }




}
    
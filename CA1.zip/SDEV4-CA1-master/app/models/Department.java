package models;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Department extends Model{
    @Id
    private Long id;

    @Constraints.Required
    private String name;

@OneToMany (cascade = CascadeType.ALL , mappedBy = "dep")
public List<Employee> employee;



    public Department() {
    }

    public Department(Long dep_id, String name, List<Employee> employee) {
        this.id = dep_id;
        this.name = name;
       this.employee=employee;
    }


  //  public static final Finder<Long, Department> find = new Finder<>(Department.class);
    
  //  public static final List<Department> findAll() {
   //     return Department.find.all();
   // }

    public Long getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public List<Employee> getEmployee() {
        return employee;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmployee(List<Employee> employee) {
        this.employee = employee;
    }

    public static Finder<Long, Department> find = new Finder<Long,Department>(Department.class);
   public static List<Department> findAll() {
       return Department.find.query().where().orderBy("name asc").findList();
   }

    public static Map<String, String> options() {
        LinkedHashMap<String, String> options = new LinkedHashMap();

        for (Department d: Department.findAll()) {
            options.put(d.getId().toString(), d.getName());
        }

        return options;
    }



}